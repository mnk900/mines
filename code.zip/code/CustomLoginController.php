<?php
namespace App\Http\Controllers\Auth;
namespace App\Http\Controllers;
use App\Models\UsefulLinks;
use App\Models\GeneralSetting;
use App\Models\Page;
use Filament\Http\Controllers\Auth\LoginController as FilamentLoginController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;

class CustomLoginController extends Controller
{
    protected $page_title = "Mines and Minerals | Department";


    protected $general_setting;

    protected $pages;

    protected $link_pages;

    protected $useful_links;
    public function __construct()
    {
        $this->general_setting = GeneralSetting::find(1);
       
        $this->pages = Page::where('is_published', 1)->with(['page', 'childpages'])->orderBy('sort_order', 'ASC')->get();
        $this->link_pages = Page::where('show_page_link_on_home', 1)->orderBy('sort_order', 'ASC')->get();
        $this->useful_links = UsefulLinks::where('is_published', 1)->orderBy('sort_order', 'ASC')->get();
    }
    public function showLoginForm()
    {
        $selected_main_menu = 'home_page';
        //dd( GeneralSetting::find(1)); exit;
        $this->page_title = "Mines and Mineral Registration Form ";
        return view('home.custom_login')
        ->with('page_title', $this->page_title) 
        ->with('selected_main_menu', $selected_main_menu)
        ->with('general_setting', $this->general_setting)
        ->with('pages', $this->pages)
        ->with('UsefulLinks', $this->useful_links)
        ->with('link_pages', $this->link_pages);
    }

    public function login(Request $request)
    {
        $cnic = $request->input('user_name');
         $password = $request->input('password');
         
 
         // Map 'cnic' to 'user_name' in the credentials array
         $credentials = [
             'user_name' => $cnic,
             'password' => $password
         ];

        if (Auth::attempt($credentials)) {
           
            // Authentication passed
            return Redirect::intended('user/applications'); // Redirect to the desired page
        }
        
        return Redirect::back()->withErrors(['email' => 'Invalid credentials.'])->withInput();
    }

    public function getchallan($appId) {
        
        $applicantDataQuery = DB::table('users')
        ->join('lease_application_registrations', 'users.id', '=', 'lease_application_registrations.user_id')
        ->join('lease_coordinates', 'lease_application_registrations.id', '=', 'lease_coordinates.application_id')
        ->select('users.*', 'lease_application_registrations.*', 'lease_coordinates.*')
        ->where('lease_application_registrations.id', '=', $appId);
     
    $applicantData = $applicantDataQuery->get();
  
    
        $selected_main_menu = 'home_page';
        //dd( GeneralSetting::find(1)); exit;
        //$this->page_title = "Lease Application Challan ";
        return view('home.app_challan')
        ->with('applicantdata', $applicantData); 
        
         
    }

}