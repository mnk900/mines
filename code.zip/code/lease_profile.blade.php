@extends('layouts.leaseprofile')

<style>
.card-body.user-profile h3 {
  width: 100%;
  margin-bottom:20px;
}
@keyframes blink {
            0% {
                opacity: 1;
            }
            50% {
                opacity: 0;
            }
            100% {
                opacity: 1;
            }
        }

        .blinking-text {
            text-align: center;
            margin-top: 20%;
            font-size: 24px;
            color: green;
            animation: blink 1s infinite; 
        }
</style>
@section('content')

    <div class="container">
    <div class="clearfix blog-list">
    @foreach ($applicantdata as $news)
                                    

    <div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Profile Information
                 <span style="font-size:13px;">
                (  Application Status: &nbsp;@if($news->application_status == 'complete')
                        <span class="blinking-text">
                        <button type="button" class="btn btn-primary btn-sm">{{ $news->application_status }}</button>
                            <button></button></span>
                    @else
                    <button type="button" class="btn btn-danger btn-sm">{{ $news->application_status }}</button>
                    @endif)</span>
                    <span>
                    <a href="{{ route('getchallan', ['appId' => $news->application_id]) }}" class="btn btn-primary btn-lg active float-right btn-sm" role="button" aria-pressed="true">
                        Download Challan <i class="fa fa-download"></i> </a> 
                    </span>
                </h4>
        </div>
        <div class="card-body user-profile">
            <div class="row">
            <h3>Applicant's Company/Firm Name</h3>    
            <div class="col-md-6">
                    <p><strong>Company Name:</strong> <span> {{ $news->company_name ; }}</span></p>
            </div>
            <div class="col-md-6">
                    <p><strong>Company Address:</strong> <span>{{ $news->business_address;}} </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Authorized Person Name:</strong> <span>{{ $news->authorize_person; }}</span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Designation:</strong> <span> {{ $news->designation ; }}</span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Phone Number:</strong> <span> {{ $news->office_no ; }}</span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Company Cell no:</strong> <span>{{ $news->cell_no ; }} </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Applicant Email:</strong> <span>{{ $news->email ; }} </span></p>
                </div>
                <h3>Organizational Address</h3>
               
                <div class="col-md-6">
                    <p><strong>Business Address:</strong> <span> {{ $news->business_address; }} </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>NTN No:</strong> <span>{{ $news->ntn_no;}} </span></p>
                </div>

                <div class="col-md-6">
                    <p><strong>GST No:</strong> <span> {{$news->gst_no ;}} </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong> Nature of Business :</strong> <span> {{ $news->nature_business; }} </span></p>
                </div>
                <h3>Attached Compay Documents</h3>
                <div class="col-md-6">
                    <p><strong>Firm Registration:</strong> <span>
                    <a href="{{$news->firm_registration;}}"> Download </a> </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Deed Partnership</strong> <span>
                    <a href="{{ $news->deed_partnership;}}">Download </a> </span></p>
                </div>
                <h3>License Category </h3>
                <div class="col-md-6">
                    <p><strong>Name of Mineral Applied For:</strong> <span>{{ $news->name_mineral; }} </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Site Location:</strong> <span> {{ $news->location;}}  </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Total Covered Area:</strong> <span> {{ $news->covered_area;}} </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Coordinates: </strong> <span>{{ $news->longitude;}},{{ $news->latitude;}}</span></p>
                </div>
                
              
                                            
                <div class="col-md-6">
                    <p><strong>Applicant CNIC:</strong> <span>  {{ $news->user_name;}}   </span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Applicant Email:</strong> <span>{{ $news->email; }}  </span></p>
                </div>
              
            </div>
        </div>
    </div>
</div>
                                    <hr class="invis" />
                                @endforeach
                            </div>
                            <!-- end blog-list -->
                        </div>
        
    </div>



</section>


@stop


@push('scripts')
<script></script>
@endpush